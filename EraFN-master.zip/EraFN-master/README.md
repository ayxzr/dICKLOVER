# Era Source Code.
[MinHook](https://github.com/TsudaKageyu/minhook): Used for hooking into Fortnite, you can read MinHook's license [here](https://raw.githubusercontent.com/TsudaKageyu/minhook/master/LICENSE.txt). <br />
[cURL](https://curl.se): Used for redirecting Fortnite's server requests to a local server, you can read cURL's license [here](https://curl.se/docs/copyright.html).


made by danii, kyiro, mix and fischsalat.
